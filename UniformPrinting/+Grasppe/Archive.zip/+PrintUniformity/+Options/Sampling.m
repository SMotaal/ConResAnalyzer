classdef Sampling
  enumeration
    Patches
    Blocks
    Circumferential
    Axial
    Sections
    InkZones
    InkZoneBands
  end  
end

