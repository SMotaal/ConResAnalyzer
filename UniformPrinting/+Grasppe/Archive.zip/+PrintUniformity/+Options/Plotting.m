classdef Plotting
  enumeration
    Scatter
    Surface    
    Patch
  end  
end

