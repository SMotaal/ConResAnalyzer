classdef Defaults < Grasppe.Core.ValueEnumeration
  
  enumeration
    %% Persistent Data Options
    BufferSurfData    (0)
    BufferSheetData   (1)
    BufferSetData     (1)
    BufferCaseData    (1)
  end
  
end

