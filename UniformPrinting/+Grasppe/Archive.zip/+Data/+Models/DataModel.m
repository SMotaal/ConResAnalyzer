classdef DataModel < Grasppe.Core.Model
  %DATAMODEL Summary of this class goes here
  %   Detailed explanation goes here
  
  properties
  end
  
  methods
    function obj = DataModel(varargin)
      obj = obj@Grasppe.Core.Model(varargin{:});
    end
  end
  
end

